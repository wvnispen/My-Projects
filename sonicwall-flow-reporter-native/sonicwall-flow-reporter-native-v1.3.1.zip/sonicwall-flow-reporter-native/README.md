# SonicWall Flow Reporter - Native Linux Installation

**Version 1.3.0**

Real-time network flow monitoring and reporting for SonicWall firewalls using IPFIX/NetFlow.

## MAJOR FIXES in v1.3.0

Based on extensive packet capture analysis, the field mappings have been completely corrected:

### Template 257 (Main Flow Data - 39 fields):
- **Field 5** = `internal_src_ip` - The REAL internal client IP (pre-NAT) ← **KEY FIX!**
- **Field 6** = `dst_ip` - Destination IP
- **Field 7** = `nat_src_ip` - WAN IP after NAT
- **Field 10** = `user_object_id` - User object ID (integer)
- **Field 11** = `src_port` - Source port  
- **Field 12** = `dst_port` - Destination port
- **Field 18** = `app_name` - 4-character ASCII app code (e.g., "isl3", "http")
- **Field 191** = `rule_info` - Contains rule_id in lower byte

### Template 262 (URL/HTTP Data - 4 fields):
- **Field 59** = `url_host` - Full URL/hostname (e.g., "api.wyzecam.com/")
- **Field 124** = Zone information

### Fixed Issues:
- `field_def.decode()` → `field_def.decoder()` (method name fix)
- Rule ID extraction from `rule_info` field
- Internal IPs now properly captured (192.168.x.x instead of NAT'd WAN IP)
- URL/hostname data now captured from Template 262

Real-time IPFIX/NetFlow reporting for SonicWall firewalls running natively on Ubuntu 24.04 LTS (no Docker required).

## Features

- **IPFIX Collection** - Receives and parses NetFlow/IPFIX data from SonicWall firewalls
- **User Identity Mapping** - Map IPs to users via web UI, CSV import, DHCP leases, or SonicWall SSO
- **Real-time Dashboards** - Grafana dashboards for bandwidth, top talkers, application usage
- **365-Day Retention** - Tiered storage with automatic data lifecycle management
- **Native Installation** - Runs directly on Ubuntu 24.04 with systemd services

## Architecture

```
┌─────────────────┐      IPFIX/UDP:2055      ┌────────────────────────┐
│    SonicWall    │ ────────────────────────▶│    IPFIX Collector     │
│    Firewall     │                          │  (Python + systemd)    │
└─────────────────┘                          └───────────┬────────────┘
                                                         │
                                                         ▼
┌────────────────────────────────────────────────────────────────────────┐
│  Native Services on Ubuntu 24.04                                       │
│                                                                        │
│  ┌──────────────────┐  ┌──────────────────┐  ┌──────────────────────┐ │
│  │  Elasticsearch   │  │     Grafana      │  │   Identity Web UI    │ │
│  │   (apt/deb)      │  │    (apt/deb)     │  │  (Python + uvicorn)  │ │
│  └──────────────────┘  └──────────────────┘  └──────────────────────┘ │
│                                                                        │
│  ┌──────────────────┐                                                  │
│  │    Aggregator    │  Hourly rollups via systemd timer               │
│  └──────────────────┘                                                  │
└────────────────────────────────────────────────────────────────────────┘
```

## System Requirements

### Minimum
- Ubuntu 24.04 LTS (or Ubuntu 22.04)
- 4 vCPUs
- 8 GB RAM
- 100 GB SSD storage

### Recommended (production)
- 4-8 vCPUs
- 16 GB RAM  
- 500 GB SSD storage

## Quick Start (10 Minutes)

### Step 1: Download and Extract

```bash
# Download the package
unzip sonicwall-flow-reporter-native.zip
cd sonicwall-flow-reporter-native
```

### Step 2: Run the Installer

```bash
sudo bash scripts/install-native.sh
```

This script will:
1. Install prerequisites (Python, Java, build tools)
2. Install Elasticsearch 9.x from official repos
3. Install Grafana OSS from official repos
4. Create Python virtual environments for collector and identity UI
5. Set up systemd services
6. Configure firewall rules
7. Initialize Elasticsearch indices

### Step 3: Configure SonicWall IPFIX Export

On your SonicWall firewall:

1. Navigate to **Manage → Logs & Reporting → Log Settings → NetFlow/IPFIX**
2. Enable **NetFlow/IPFIX Reporting**
3. Set **Collector IP** to your server's IP address
4. Set **Port** to `2055`
5. Set **Version** to `IPFIX` (or NetFlow v9)
6. Select templates to export
7. Click **Accept** to save

### Step 4: Access the Interfaces

| Service | URL | Default Login |
|---------|-----|---------------|
| **Grafana** | http://YOUR_IP:3000 | admin / admin |
| **Identity UI** | http://YOUR_IP:8080 | admin / admin |

---

## Service Management

### View Service Status

```bash
# All custom services
sudo systemctl status swfr-collector
sudo systemctl status swfr-identity

# Elasticsearch and Grafana
sudo systemctl status elasticsearch
sudo systemctl status grafana-server
```

### Start/Stop/Restart Services

```bash
# IPFIX Collector
sudo systemctl start swfr-collector
sudo systemctl stop swfr-collector
sudo systemctl restart swfr-collector

# Identity UI
sudo systemctl start swfr-identity
sudo systemctl stop swfr-identity
sudo systemctl restart swfr-identity

# Restart all
sudo systemctl restart elasticsearch grafana-server swfr-collector swfr-identity
```

### View Logs

```bash
# IPFIX Collector logs
sudo journalctl -u swfr-collector -f
cat /var/log/sonicwall-flow-reporter/collector.log

# Identity UI logs
sudo journalctl -u swfr-identity -f
cat /var/log/sonicwall-flow-reporter/identity-ui.log

# Elasticsearch logs
sudo journalctl -u elasticsearch -f

# Grafana logs
sudo journalctl -u grafana-server -f
```

---

## Configuration

### Main Configuration File

Edit `/etc/sonicwall-flow-reporter/config.env`:

```bash
sudo nano /etc/sonicwall-flow-reporter/config.env
```

```bash
# Elasticsearch
ELASTICSEARCH_HOST=127.0.0.1
ELASTICSEARCH_PORT=9200

# IPFIX Collector
IPFIX_LISTEN_IP=0.0.0.0
IPFIX_LISTEN_PORT=2055

# Identity UI
IDENTITY_UI_HOST=0.0.0.0
IDENTITY_UI_PORT=8080
IDENTITY_ADMIN_PASSWORD=your-secure-password
SECRET_KEY=change-this-to-a-random-32-character-string

# Optional: SonicWall SSO
SONICWALL_SSO_ENABLED=false
SONICWALL_HOST=192.168.1.1
SONICWALL_API_USER=admin
SONICWALL_API_PASSWORD=your-firewall-password
```

After editing, restart services:
```bash
sudo systemctl restart swfr-collector swfr-identity
```

### Elasticsearch Configuration

Edit `/etc/elasticsearch/elasticsearch.yml`:

```bash
sudo nano /etc/elasticsearch/elasticsearch.yml
```

Key settings:
```yaml
cluster.name: sonicwall-flow-reporter
node.name: node-1
network.host: 127.0.0.1
http.port: 9200
discovery.type: single-node
xpack.security.enabled: false
```

### Elasticsearch JVM Heap

Edit `/etc/elasticsearch/jvm.options.d/heap.options`:

```bash
-Xms4g
-Xmx4g
```

Set to 50% of available RAM, max 31GB.

### Grafana Configuration

Edit `/etc/grafana/grafana.ini`:

```bash
sudo nano /etc/grafana/grafana.ini
```

Change admin password:
```ini
[security]
admin_password = your-secure-password
```

---

## Directory Structure

```
/opt/sonicwall-flow-reporter/
├── collector/              # IPFIX collector Python app
│   ├── venv/              # Python virtual environment
│   ├── main.py            # Entry point
│   ├── ipfix_collector.py # Collector logic
│   └── ...
├── identity-ui/           # Identity management web app
│   ├── venv/              # Python virtual environment
│   ├── app.py             # FastAPI application
│   └── templates/         # HTML templates
└── grafana/               # Dashboard JSON files

/var/lib/sonicwall-flow-reporter/
├── elasticsearch/         # ES data (if configured)
└── identity-db/           # Identity database

/var/log/sonicwall-flow-reporter/
├── collector.log          # IPFIX collector logs
├── identity-ui.log        # Web UI logs
└── aggregator.log         # Aggregator logs

/etc/sonicwall-flow-reporter/
└── config.env             # Main configuration
```

---

## Identity Management

Access the Identity UI at http://YOUR_IP:8080

### Import Methods

1. **Manual Entry** - Add individual IP-to-user mappings
2. **CSV Import** - Bulk import from spreadsheet
3. **DHCP Import** - Import from various DHCP servers:
   - SonicWall DHCP Server
   - ISC DHCP (dhcpd.conf)
   - dnsmasq
   - Windows DHCP Server
   - MikroTik RouterOS
   - OPNsense/pfSense
4. **SonicWall SSO** - Auto-sync from firewall API

---

## Maintenance

### Check Disk Usage

```bash
# Elasticsearch disk usage
curl -s http://localhost:9200/_cat/indices?v | sort -k9 -h

# Overall disk
df -h /var/lib/elasticsearch
```

### Backup

```bash
# Stop services for consistent backup
sudo systemctl stop swfr-collector swfr-identity

# Backup Elasticsearch (snapshot recommended for production)
sudo tar -czf backup-$(date +%Y%m%d).tar.gz \
    /var/lib/elasticsearch \
    /etc/sonicwall-flow-reporter \
    /opt/sonicwall-flow-reporter

# Restart
sudo systemctl start swfr-collector swfr-identity
```

### Update Application

```bash
# Stop services
sudo systemctl stop swfr-collector swfr-identity

# Backup current version
sudo cp -r /opt/sonicwall-flow-reporter /opt/sonicwall-flow-reporter.bak

# Extract new version
cd /tmp
unzip sonicwall-flow-reporter-native-NEW.zip
sudo cp -r sonicwall-flow-reporter-native/collector/* /opt/sonicwall-flow-reporter/collector/
sudo cp -r sonicwall-flow-reporter-native/identity-ui/* /opt/sonicwall-flow-reporter/identity-ui/

# Set permissions
sudo chown -R swfr:swfr /opt/sonicwall-flow-reporter

# Restart
sudo systemctl start swfr-collector swfr-identity
```

---

## Troubleshooting

### No Data in Grafana

1. **Check collector is receiving data:**
   ```bash
   sudo journalctl -u swfr-collector | tail -20
   ```
   Look for: `Stats: packets=X, flows=X`

2. **Verify UDP traffic:**
   ```bash
   sudo tcpdump -i any port 2055 -c 10 -n
   ```

3. **Check Elasticsearch:**
   ```bash
   curl http://localhost:9200/flows/_count
   ```

4. **Verify firewall:**
   ```bash
   sudo ufw status
   ```

### Elasticsearch Won't Start

```bash
# Check logs
sudo journalctl -u elasticsearch

# Verify memory settings
sudo sysctl vm.max_map_count

# Fix if needed
sudo sysctl -w vm.max_map_count=262144
```

### Identity UI Not Accessible

```bash
# Check service
sudo systemctl status swfr-identity

# Check logs
cat /var/log/sonicwall-flow-reporter/identity-ui.log

# Verify port
ss -tlnp | grep 8080
```

---

## Uninstall

To completely remove the installation:

```bash
sudo bash scripts/uninstall.sh
```

This removes:
- All SonicWall Flow Reporter services
- Elasticsearch and data
- Grafana
- Application files
- Service user

---

## Ports Reference

| Port | Protocol | Service | Description |
|------|----------|---------|-------------|
| 2055 | UDP | IPFIX Collector | Flow data from SonicWall |
| 3000 | TCP | Grafana | Web dashboards |
| 8080 | TCP | Identity UI | User mapping management |
| 9200 | TCP | Elasticsearch | Data storage (localhost only) |

---

## Security Notes

1. **Elasticsearch** runs with security disabled and binds to localhost only
2. **Grafana** - Change the default admin password immediately
3. **Identity UI** - Change the default password in config.env
4. **Firewall** - Only ports 22, 2055, 3000, 8080 are exposed

For production deployments, consider:
- Enabling Elasticsearch security
- Setting up HTTPS for Grafana and Identity UI
- Using a reverse proxy (nginx) with SSL certificates
- Restricting IPFIX sources by IP

---

## License

MIT License - Free for commercial and personal use.
